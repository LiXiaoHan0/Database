# 2022北京冬奥会信息管理系统

2021秋  数据库技术及应用大作业

## 不留大作业过年！

![image-20211231210726767](figures/cover.png)

---

Author: Han Li, Yi Zheng

### Requirements

- Developed on Windows
- Python 3.8.12/3.8.5
- cx_oracle 8.2.1
- Matplotlib 3.4.3
- Instant Client (Please download a suitable version through https://www.oracle.com/cn/database/technology/instant-client.html)